cette epreuve est en trois parties, la validation s'effectue sous la forme:
pass1:pass2:pass3
